**Describe the PR**
e.g. add cool parser.

**Relation issue**
e.g. https://github.com/swaggo/gin-swagger/pull/123/files

**Additional context**
Add any other context about the problem here.
