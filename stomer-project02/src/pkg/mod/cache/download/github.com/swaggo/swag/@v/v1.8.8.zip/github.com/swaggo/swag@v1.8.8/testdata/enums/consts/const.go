package consts

const Base = 1
