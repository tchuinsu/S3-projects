package main

// @title Swagger Example API
// @version 1.0
// @description Parse external models.
// @BasePath /v1
func main() {
}
