package othertypes

type Application struct {
	ID int
}
