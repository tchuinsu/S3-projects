package external2

type Customer struct {
	Name string
	Age  int
}
