# Security

## Reporting Security Issues

Please *DO NOT* report security vulnerabilities with public GitHub issue
reports. Please [report security issues here](
https://www.splunk.com/en_us/product-security/report.html).
