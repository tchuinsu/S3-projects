---
title: API reference
linkTitle: API
redirect: https://pkg.go.dev/go.opentelemetry.io/otel
manualLinkTarget: _blank
_build: { render: link }
weight: 50
---
