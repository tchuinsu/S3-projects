---
title: Examples
redirect: https://github.com/open-telemetry/opentelemetry-go/tree/main/example
manualLinkTarget: _blank
_build: { render: link }
weight: 60
---
